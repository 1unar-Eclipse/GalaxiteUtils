// Auto-Module: Automatically toggles the state of certain modules in certain games.
// List:
// - The Entity: Toggle Sprint
// - Chronos: Coordinates

// import notOnGalaxite from "index";