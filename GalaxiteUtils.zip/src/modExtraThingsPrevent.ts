// Extra Things Prevent: Makes you need to click twice to use Extra Things.
// Dependencies: action event; I am not hardcoding the button for this

/*
// Setup
import notOnGalaxite from "./index";

const mod = new Module(
    "etdc",
    "Extra Things Prevent",
    "Makes you need to double-click to use Extra Things",
    KeyCode.None
);
client.getModuleManager().registerModule(mod);

// Save the player
let user;

client.on("join-game", e => {
    user = game.getLocalPlayer();
});
*/