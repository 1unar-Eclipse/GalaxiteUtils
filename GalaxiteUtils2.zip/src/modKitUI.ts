// Kit UI: Shows your selected perk (Chronos), engine (Hyper Racers), loot modifier (Rush), or kit (Kit PvP).
// Dependencies: Advanced Mode for Chronos/Kits will need a few assorted things, though it is not the most needed.

/*
Chronos: Icon + perk name
Chronos (Advanced): Icon + advanced thing
Rush: Lines for each in-game loot mod, icon + count
Hyper Racers: Engine + track name
Kit PvP: Icon + kit name */

// import notOnGalaxite from "index";