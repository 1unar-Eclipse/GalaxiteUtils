// Bossbar UI: Ports details from the bossbar to UI. Recommended for use with the Bossbar module.
// Dependencies: Reading bossbar

// import notOnGalaxite from "index";