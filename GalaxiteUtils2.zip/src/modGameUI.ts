// Game UI: Shows what game and team size you're playing.
// Dependencies: None!

// import notOnGalaxite from "index";