// Parkour Builders Attempts: Shows current attempts on a Parkour Builders run.
// Dependencies: Not sure

// import notOnGalaxite from "index";