// WhereAmIHUD: Allows showing various details from the /whereami command, like game or region.
// Dependencies: server join event

// import notOnGalaxite from "index";