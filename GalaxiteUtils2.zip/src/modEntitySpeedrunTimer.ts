// Entity Speedrun Timer: Automates speedrun splits for The Entity, though it's just a timer right now.
// Dependencies: Title event

// import notOnGalaxite from "index";